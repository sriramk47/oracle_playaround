// this is kind of DB repo of all functions having sql statements

const oracledb = require('oracledb');
oracledb.initOracleClient({ libDir: 'D:\\instantclient-basic-windows.x64-23.6.0.24.10\\instantclient_23_6' })

// const { json } = require('express');

let dbcon=require('../database/oracle_playground');
import dbconimp from '../database/oracle_playground';
const stgdb={
    user:"ksriram",
    password:"dreamer369",
    connectionString: "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=devel.talk4free.com)(PORT=1521))(CONNECT_DATA=(SID=stgdb)))"
};
//await functions work good inside async functions.
async function run() {
    // let connection = await dbconimp.createConnection(); //this is not working..why???
    // let connection = await dbcon.createConnection(); // this is also not working
    let connection= await oracledb.getConnection(stgdb);
    //prepare sqlquery unlike below :-p
    //here we can also use " instead of `
    connection.execute(`select accountid,active from ymax.account where accountid> :accid and added >to_date(:date1,'dd-mm-yyyy') and rownum < :duck`, {accid: 12345, date1: '01-01-2001', duck:10},{maxRows:6},(error,result) => {
        if(error){
            console.log(error);
            console.error("Error while executing query");
        }
        else{
            console.log(result.rows);
        }
    });
    // console.log(queryresult.rows);
}

run();