const oracledb = require('oracledb');
const dbconfig = require('./dbconfig');
oracledb.outFormat=oracledb.OUT_FORMAT_OBJECT;
oracledb.initOracleClient({libDir:'D:\\instantclient-basic-windows.x64-23.6.0.24.10\\instantclient_23_6'});

//using try catch
// async function createconnection(){
//     try{
//         let connection = await oracledb.getConnection(dbconfig.stgdb);
//         console.log("Connected to database successfully")
//     }
//     catch(excp){
//         console.error(excp);
//         console.error("You are ducked up");
//     }
// }


let dbconnection=null;
//resolving promise with .then(success) and .catch(failure)
export async function createConnection(){
    await oracledb.getConnection(dbconfig.stgdb).then((data) => {
        dbconnection = data;
        console.log("Connected to database successfully");
    }).catch((error) => {
        console.log(error);
        console.error("Unable to connect...");
    }
    )
}


// async function insert_login_data(p_username,p_password){
//     const insert_query=`insert into ksriram.login_data(username,password) values($p_username,$p_password)`;
// }
//const querydata=await dbconnection.execute(`select accountid,active,fraud_account from ymax.account where rownum<4`);
//         console.log(querydata.rows);
module.exports = {
    createConnection
}

// export default createconnection;