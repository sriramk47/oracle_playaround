
const stgdb={
    user:"ksriram",
    password:"dreamer369",
    connectionString: "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=devel.talk4free.com)(PORT=1521))(CONNECT_DATA=(SID=stgdb)))"
};

module.exports={
    stgdb
}